#ifndef ROBOT_CONFIG_HPP
#define ROBOT_CONFIG_HPP

#include "main.h" // IWYU pragma: keep
#include "lemlib/api.hpp" // IWYU pragma: keep

// -------------------
// Robot configuration
// -------------------

extern pros::Controller controller;
extern pros::MotorGroup left_motor_group;
extern pros::MotorGroup right_motors;
extern lemlib::Drivetrain drivetrain;
extern pros::Imu imu;
extern pros::Rotation horizontal_rotation_sensor;
extern pros::Rotation vertical_rotation_sensor;
extern lemlib::TrackingWheel horizontal_tracking_wheel;
extern lemlib::TrackingWheel vertical_tracking_wheel;
extern lemlib::OdomSensors sensors;
extern lemlib::ControllerSettings lateral_controller;
extern lemlib::ControllerSettings angular_controller;
extern lemlib::ExpoDriveCurve throttleCurve;
extern lemlib::ExpoDriveCurve steerCurve;
extern lemlib::Chassis chassis;

#endif // ROBOT_CONFIG_HPP